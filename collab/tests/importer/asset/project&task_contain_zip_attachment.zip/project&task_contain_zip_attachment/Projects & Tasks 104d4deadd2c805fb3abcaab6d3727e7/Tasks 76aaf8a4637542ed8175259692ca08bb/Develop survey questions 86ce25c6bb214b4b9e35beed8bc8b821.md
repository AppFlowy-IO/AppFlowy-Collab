# Develop survey questions

Assignee: Sohrab Amin
Status: Done
Due: April 21, 2024
Project: Research study (../Projects%2058b8977d6e4444a98ec4d64176a071e5/Research%20study%20e445ee1fb7ff4591be2de17d906df97e.md)
Priority: Medium
Tags: Research
Completed on: April 28, 2024
Delay: 7
Is Blocking: Conduct interviews (Conduct%20interviews%208f40c17883904d769fee19baeb0d46a5.md)

- Ready to collaborate with your team? Use the Share menu at the top right.
- Use the “Assignee” field above to assign tasks to your teammates. They’ll see a notification in their sidebar.