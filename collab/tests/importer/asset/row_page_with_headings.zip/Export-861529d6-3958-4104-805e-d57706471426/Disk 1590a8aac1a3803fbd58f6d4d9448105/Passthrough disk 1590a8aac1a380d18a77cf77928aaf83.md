# Passthrough disk

Status: Not started

# Purpose

---

How to passthrough a physical disk to a VM

## How-To

---
