# Report on marketing ROI

Assignee: Ben Lang
Status: In Progress
Due: May 5, 2024
Project: Marketing campaign (../Projects%2058b8977d6e4444a98ec4d64176a071e5/Marketing%20campaign%2088ac0cea4cb245efb44d63ace0a37d1e.md)
Priority: Medium
Tags: Improvement, Marketing