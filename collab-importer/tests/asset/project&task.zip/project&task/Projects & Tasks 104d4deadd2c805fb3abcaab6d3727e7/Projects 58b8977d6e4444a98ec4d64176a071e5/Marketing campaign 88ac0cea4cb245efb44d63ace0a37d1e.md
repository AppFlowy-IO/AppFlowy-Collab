# Marketing campaign

Status: In Progress
Owner: Sohrab Amin
Completion: 0.5
Dates: April 24, 2024 → May 7, 2024
Blocked By: Research study (Research%20study%20e445ee1fb7ff4591be2de17d906df97e.md)
Delay: 19
Files & media: ../appflowy_2x.png
Is Blocking: Website redesign (Website%20redesign%20bb934cb9f0e44daab4368247d62b0f39.md)
Priority: Low
Summary: The marketing campaign, led by Sohrab Amin, focuses on enhancing mobile performance, building on last year's success in reducing page load times by 50%. The team aims to further improve performance by investing in native components for iOS and Android from April 24 to May 7, 2024.
Tasks: Define target audience (../Tasks%2076aaf8a4637542ed8175259692ca08bb/Define%20target%20audience%2045e2d3342bfe44848009f8e19e65b2af.md), Develop advertising plan (../Tasks%2076aaf8a4637542ed8175259692ca08bb/Develop%20advertising%20plan%20a8e534ad763040029d0feb27fdb1820d.md), Report on marketing ROI (../Tasks%2076aaf8a4637542ed8175259692ca08bb/Report%20on%20marketing%20ROI%202458b6a0f0174f72af3e5daac8b36b08.md), Create social media plan (../Tasks%2076aaf8a4637542ed8175259692ca08bb/Create%20social%20media%20plan%204e70ea0b7d40427a9648bcf554a121f6.md), Create performance marketing plan (../Tasks%2076aaf8a4637542ed8175259692ca08bb/Create%20performance%20marketing%20plan%20b6aa6a9e9cc1446490984eaecc4930c7.md), Develop new creative assets (../Tasks%2076aaf8a4637542ed8175259692ca08bb/Develop%20new%20creative%20assets%203268a1d63424427ba1f7e3cac109cefa.md)

## About this project

Last year, the team prioritized mobile performance, and successfully reduced page load times by 50%. This directly correlated with increased mobile usage, and more positive app store reviews.

This quarter, the mobile team is doubling down on performance, and investing in more native components across iOS and Android.

## Performance dashboards

## Project tasks

[Tasks](Marketing%20campaign%2088ac0cea4cb245efb44d63ace0a37d1e/Tasks%2042a63a9fe6df4a39a8d5b4804e0eae9f.csv)