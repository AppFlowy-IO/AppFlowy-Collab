# Front end design system

Assign: Ryo
Status: Not Started
Priority: Medium
Date Created: September 17, 2024 1:52 PM
Due Date: November 7, 2022
Sprint: Sprint 20
Day: Monday

# Description

Improve our alignment with engineering by creating a shared design system library.

# **To-do**

- [x]  Meet with engineering to create a standardized library of reusable components
- [x]  Implement React Storybook
- [ ]  Review components for consistency
- [ ]  Provide feedback to engineering

[https://www.youtube.com/watch?time_continue=2&v=p-LFh5Y89eM](https://www.youtube.com/watch?time_continue=2&v=p-LFh5Y89eM)

[Storybook: UI component explorer for frontend developers](https://storybook.js.org/)