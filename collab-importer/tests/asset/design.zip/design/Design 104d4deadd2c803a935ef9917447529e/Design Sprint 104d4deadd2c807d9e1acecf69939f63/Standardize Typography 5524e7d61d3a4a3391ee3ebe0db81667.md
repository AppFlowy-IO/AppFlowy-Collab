# Standardize Typography

Assign: Sohrab Amin
Status: Next Up
Priority: Low
Date Created: September 17, 2024 1:52 PM
Due Date: November 28, 2022
Sprint: Sprint 22
Day: Tuesday

<aside>
💡 When you create a new task, select `Task` from the list of available templates to automatically generate the format below. Learn more about templates [here](https://www.notion.so/454ed5ab5bd24226b58d176697bd7e10?pvs=21).

</aside>

# Description

Over the years, we've added various fonts and weights.
We need to standardize our approach and settle on a single font.

# **To-do**

- [ ]  Document existing headline styles: h1, h2, h3, h4, h5, h6
- [ ]  Standardize sizes and weights
- [ ]  Update component library
- [ ]  Audit site to ensure all headers are using new components