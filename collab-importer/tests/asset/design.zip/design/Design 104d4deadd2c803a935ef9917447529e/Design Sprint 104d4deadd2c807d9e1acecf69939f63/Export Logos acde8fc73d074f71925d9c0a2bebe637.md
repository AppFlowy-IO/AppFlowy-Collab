# Export Logos

Assign: Holly Turay
Status: In Progress
Priority: High 🔥
Date Created: September 17, 2024 1:52 PM
Due Date: November 17, 2022
Sprint: Sprint 22
Day: Tuesday

# Description

Logos requested by marketing for Fall campaign.

# To-do

Export logo / banner for social platforms:

- [x]  1000 x 1000px avatar
- [x]  1500 x 500px banner

![Export%20Logos%20acde8fc73d074f71925d9c0a2bebe637/acme-corp-avatar-inverse.png](Export%20Logos%20acde8fc73d074f71925d9c0a2bebe637/acme-corp-avatar-inverse.png)

![Export%20Logos%20acde8fc73d074f71925d9c0a2bebe637/acme-corp-social-banner.png](Export%20Logos%20acde8fc73d074f71925d9c0a2bebe637/acme-corp-social-banner.png)