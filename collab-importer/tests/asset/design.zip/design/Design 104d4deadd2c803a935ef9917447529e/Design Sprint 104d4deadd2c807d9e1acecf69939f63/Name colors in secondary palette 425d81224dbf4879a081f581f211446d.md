# Name colors in secondary palette

Assign: Akhila Thalla
Status: Next Up
Priority: Medium
Date Created: September 17, 2024 1:52 PM
Due Date: November 27, 2022
Sprint: Sprint 21
Day: Friday

# Description

With 6 shades of gray in our color palette, it's become difficult to communicate between the design and engineering teams.

Instead of `$gray-1` or `$gray-2`, let's choose more descriptive names like `$color-smoke` or `$color-ash`.

# **To-do**

- [ ]  Choose new color names
- [ ]  Work with engineering to update component library
- [ ]  Implement new components