# Audit button colors

Assign: Ivan Zhao
Status: Next Up
Priority: Medium
Date Created: September 17, 2024 1:52 PM
Due Date: November 7, 2022
Sprint: Sprint 20
Day: Monday

# Description

Some buttons are using an incorrect shade of blue.

# **To-do**

- [ ]  Double check all button colors in app
- [ ]  Update all to `#0061FF`