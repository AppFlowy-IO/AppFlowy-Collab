# Consistent Figma artboard naming

Assign: penny 🐧, Christina Lin
Status: Next Up
Priority: Low
Date Created: September 17, 2024 1:52 PM
Due Date: November 8, 2022
Sprint: Sprint 21
Day: Thursday

# Description

Settle on Figma artboard naming convention.

# To-do

Update all artboards to use kebab case:

```bash
kebab-case-looks-like-this
```