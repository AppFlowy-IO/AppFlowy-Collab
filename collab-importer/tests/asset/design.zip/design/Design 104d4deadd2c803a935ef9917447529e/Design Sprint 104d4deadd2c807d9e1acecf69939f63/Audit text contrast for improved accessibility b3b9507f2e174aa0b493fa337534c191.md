# Audit text contrast for improved accessibility

Assign: Garrett Fidalgo
Status: Completed
Priority: High 🔥
Date Created: September 17, 2024 1:52 PM
Due Date: November 20, 2022
Sprint: Sprint 21
Day: Wednesday

# Description

Acme Corp supports Level AA accessibility as defined in the [WCAG accessibility guidelines](http://www.w3.org/TR/WCAG20/#visual-audio-contrast). 

# **To-do**

- [x]  Identify areas of app with poor text / background contrast
- [x]  Run hex values through [Colorable](http://jxnblk.com/colorable/demos/text/)
- [x]  Adjust values to match Level AA requirements

This tool will be helpful to check contrast:

[Colorable](http://jxnblk.com/colorable/demos/text/)