# Poster design

Created: September 17, 2024 1:52 PM
Tags: Brand, Graphic design
Link: Add your link here →

### The idea

---

![Untitled](Poster%20design%20cdaeb11a214a4edd870a28a796c8cffd/Untitled.png)

- 

### The process

---

[https://www.notion.so](https://www.notion.so)

- 

### The design

---