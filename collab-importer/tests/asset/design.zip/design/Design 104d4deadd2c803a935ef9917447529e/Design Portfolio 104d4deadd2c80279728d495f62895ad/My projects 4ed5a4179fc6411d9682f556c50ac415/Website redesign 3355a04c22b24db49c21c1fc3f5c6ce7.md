# Website redesign

Created: September 17, 2024 1:52 PM
Tags: Brand, UI/UX
Link: Add your link here →

<aside>
💡 **Notion Tip:** Add more details right in this page, including toggles, images, and more. Break up the page by using our different header options so that it’s easier to read. Learn more about different types of content blocks [here](https://www.notion.so/guides/types-of-content-blocks).

</aside>

### The idea

---

![Untitled](Website%20redesign%203355a04c22b24db49c21c1fc3f5c6ce7/Untitled.png)

- 

### The process

---

[https://www.notion.so](https://www.notion.so)

- 

### The design

---