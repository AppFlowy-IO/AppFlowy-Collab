# Team feedback

DRI: Won Chung
Status: 50% Complete
Team: Product
Date: May 21, 2023 → May 27, 2023

<aside>
💡 **Notion Tip:** Add more details about this deliverable right in this page, including toggles, images, and more. Break up the page by using our different header options so that it’s easier to read. Learn more about different types of content blocks [here](https://www.notion.so/guides/types-of-content-blocks).

</aside>