# Design Portfolio

<aside>
💡 **Notion Tip:** Use this template to showcase the projects you’ve worked and provide more context on their purpose and the process involved. It’s easy to share this page with anyone by turning on the “Share to Web” feature under the `Share` menu above. Learn more [here](https://www.notion.so/help/public-pages-and-web-publishing).

</aside>

> 👋 Hi, I’m Mary - a web designer based out of San Francisco.
> 

↓ Click into each project to learn more about its creation, goal and current version.

[My projects](Design%20Portfolio%20104d4deadd2c80279728d495f62895ad/My%20projects%204ed5a4179fc6411d9682f556c50ac415.csv)

---

[**📨 Email Me →**](mailto:)

[**🤙 Call Me →**](tel:)

[**📝 My Resume →**](https://www.notion.so/templates/resume)