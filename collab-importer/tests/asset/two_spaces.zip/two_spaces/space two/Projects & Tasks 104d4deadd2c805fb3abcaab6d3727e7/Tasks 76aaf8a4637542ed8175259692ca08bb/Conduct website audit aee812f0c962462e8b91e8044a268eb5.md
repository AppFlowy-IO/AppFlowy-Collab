# Conduct website audit

Assignee: Sohrab Amin
Status: Not Started
Due: May 10, 2024
Project: Website redesign (../Projects%2058b8977d6e4444a98ec4d64176a071e5/Website%20redesign%20bb934cb9f0e44daab4368247d62b0f39.md)
Priority: Medium
Tags: Website
Is Blocking: Write website copy (Write%20website%20copy%209ab9309ceae34f6f8dc19b2eeda8f8f2.md)