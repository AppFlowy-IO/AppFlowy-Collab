# Develop creative assets

Assignee: Nate Martins
Status: Not Started
Due: May 13, 2024
Project: Website redesign (../Projects%2058b8977d6e4444a98ec4d64176a071e5/Website%20redesign%20bb934cb9f0e44daab4368247d62b0f39.md)
Priority: Medium
Tags: Branding, Website