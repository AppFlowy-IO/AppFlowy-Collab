# Conduct interviews

Assignee: Sohrab Amin
Status: In Progress
Due: May 12, 2024
Project: Research study (../Projects%2058b8977d6e4444a98ec4d64176a071e5/Research%20study%20e445ee1fb7ff4591be2de17d906df97e.md)
Priority: High
Tags: Research
Blocked By: Develop survey questions (Develop%20survey%20questions%2086ce25c6bb214b4b9e35beed8bc8b821.md)
Is Blocking: Interpret findings (Interpret%20findings%20c418ae6385f94dcdadca1423ad60146b.md)